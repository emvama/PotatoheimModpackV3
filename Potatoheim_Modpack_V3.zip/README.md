# Potatoheim patreon server Modpack Season2
A Modpack for usage on Potatoheim Patreonserver Season 2 - Version 3

<details>
  <summary><b><span style="color:aqua;font-weight:200;font-size:20px">
    Changelog
</span></b></summary>

| Version | Changes                                                                                                                                                                                                                                                                                                                                |
|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| v3.0.0  | modpack updated and additional mods added<br/>
| v2.0.0  | additional mods added<br/>
| v1.0.3  | add itemstands - congrats on defeating moder!<br/>
| v1.0.2  | remove devcommands<br/>
| v1.0.1  | add fuel eternal and plant everything<br/>
| v1.0.0  | initial release, only containing FastLink<br/> 
</details>
